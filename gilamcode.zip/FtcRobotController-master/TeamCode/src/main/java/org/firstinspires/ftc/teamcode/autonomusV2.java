/*
        package org.firstinspires.ftc.teamcode;

import android.util.Size;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.vision.VisionPortal;
import org.firstinspires.ftc.vision.apriltag.AprilTagDetection;
import org.firstinspires.ftc.vision.apriltag.AprilTagProcessor;

@Autonomous (name = "name")
public class autonomusV2 extends LinearOpMode {
    protected Servo pixelArmAngle;
    protected Servo pixelGrabberRight;
    protected Servo pixelGrabberLeft;
    protected Servo airPlaneServo;
    protected DcMotor robotGearRight;
    protected DcMotor robotGearLeft;
    protected DcMotor liftMotorRight;
    protected DcMotor liftMotorLeft;
    double ticks = 288;
    double newTarget;
    double robotFrontBack, robotRightLeft, liftUpDown, pixelAngle = 0;
    double[] speedBoost = {0.35, 0.7, 1};
    int count = 0;
    int liftCount = 0;
    // here
    AprilTagProcessor tagProcessor = new AprilTagProcessor.Builder()
            .setDrawAxes(true)
            .setDrawCubeProjection(true)
            .setDrawTagID(true)
            .setDrawTagOutline(true)
            .build();

    VisionPortal visionPortal = new VisionPortal.Builder()
            .addProcessor(tagProcessor)
            .setCamera(hardwareMap.get(WebcamName.class, "Webcam1"))
            .setCameraResolution(new Size(640, 480))

            .build();

    @Override
    public void runOpMode() throws InterruptedException {
    robotGearRight = hardwareMap.get(DcMotor.class, "driveR");
    robotGearLeft = hardwareMap.get(DcMotor.class, "driveL");
    liftMotorRight = hardwareMap.get(DcMotor.class, "liftR");
    liftMotorLeft = hardwareMap.get(DcMotor.class, "liftL");

    pixelArmAngle = hardwareMap.get(Servo.class, "pixelAngle");
    pixelGrabberRight = hardwareMap.get(Servo.class, "grabberR");
    pixelGrabberLeft = hardwareMap.get(Servo.class, "grabberL");
    airPlaneServo = hardwareMap.get(Servo.class, "planeS");

        robotGearRight.setDirection(DcMotorSimple.Direction.REVERSE);
        robotGearLeft.setDirection(DcMotorSimple.Direction.FORWARD);
        liftMotorRight.setDirection(DcMotorSimple.Direction.FORWARD);
        liftMotorLeft.setDirection(DcMotorSimple.Direction.REVERSE);
        pixelArmAngle.setDirection(Servo.Direction.FORWARD);
        pixelGrabberRight.setDirection(Servo.Direction.FORWARD);
        pixelGrabberLeft.setDirection(Servo.Direction.FORWARD);
        airPlaneServo.setDirection(Servo.Direction.FORWARD);






        waitForStart();


        while (!isStopRequested() && opModeIsActive())
            if (tagProcessor.getDetections().size() > 0) {
                AprilTagDetection tag = tagProcessor.getDetections().get(0);

                String caption;
                telemetry.addData("x", tag.ftcPose.x);
                telemetry.addData("y", tag.ftcPose.y);
                telemetry.addData("z", tag.ftcPose.z);
                telemetry.addData("roll", tag.ftcPose.roll);
                telemetry.addData("pitch", tag.ftcPose.pitch);
                telemetry.addData("yaw", tag.ftcPose.yaw);

                if (tag.ftcPose.x >1){
                    //go right
                    robotGearRight.setPower(0.5);
                    robotGearLeft.setPower(0.5);
                    sleep(1500);
                    robotGearRight.setPower(0);
                    robotGearLeft.setPower(0);
                }

                if (-1<tag.ftcPose.x<1) {
                    //go stright
                    robotGearRight.setPower(0.5);
                    robotGearLeft.setPower(0.5);
                    sleep(1500);
                    robotGearRight.setPower(0);
                    robotGearLeft.setPower(0);
                }
                if (tag.ftcPose.x<-1) { // go left
                    robotGearRight.setPower(0.5);
                    robotGearLeft.setPower(0.5);
                    sleep(1500);
                    robotGearRight.setPower(0);
                    robotGearLeft.setPower(0);

                }
                }

            }

        robotGearRight.setPower(0.5);
        robotGearLeft.setPower(0.5);
        sleep(1500);
        robotGearRight.setPower(0);
        robotGearLeft.setPower(0);
        start();
        pixelArmAngle.setPosition(0.45);
        sleep(1500);
        start();
        pixelGrabberRight.setPosition(0);
        pixelGrabberLeft.setPosition(0.3);
        sleep(1500);
        pixelArmAngle.setPosition(1);
        start();
        robotGearRight.setPower(0.5);
        robotGearLeft.setPower(0.2);
        sleep(1000);
        robotGearRight.setPower(0.5);
        robotGearLeft.setPower(0.5);
        sleep(1000);
        start();
        pixelGrabberRight.setPosition(0);
        pixelGrabberLeft.setPosition(0);
        sleep(1000);

        if (tagProcessor.getDetections().get(0))


    }

    public void testingAuto (int power, int position, int time){
        robotGearRight.setPower(power); // driving forwords
        robotGearLeft.setPower(power);// driving forwords
        sleep(time);// for about 1.5 seconds
        robotGearRight.setPower(power);// driving sttoped
        robotGearLeft.setPower(power);// driving sttoped
        start();
        pixelArmAngle.setPosition(position);// servo for angle of grabbers set position to 0.45
        sleep(time);// for around a 1.5 seconds
        start();
        pixelGrabberRight.setPosition(position);// right pixel grabber set position set to 0
        pixelGrabberLeft.setPosition(position);// left pixel grabber set position set to 0.3
        sleep(time);
        pixelArmAngle.setPosition(position);//
        start();
        robotGearRight.setPower(power);
        robotGearLeft.setPower(power);
        sleep(time);
        robotGearRight.setPower(power);
        robotGearLeft.setPower(power);
        sleep(time);
        start();
        pixelGrabberRight.setPosition(position);
        pixelGrabberLeft.setPosition(position);
        sleep(time);


    }
}
*/